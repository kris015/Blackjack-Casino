Hi, 

This is BlackJack casino Game, this is my training project.

Try and fun!

Developed by. Kristijan Cvetinovic  -  21.04.2020.